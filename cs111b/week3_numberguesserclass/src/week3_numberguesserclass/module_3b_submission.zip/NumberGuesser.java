package week3_numberguesserclass;

public class NumberGuesser {
	
	private int lowerBound;
	private int upperBound;
	private int origLowerBound;
	private int origUpperBound;
	
	public NumberGuesser() {
		lowerBound = 1;
		upperBound = 100;
		origLowerBound = lowerBound;
		origUpperBound = upperBound;
	}
	
	public NumberGuesser(int lowerBound, int upperBound) {
		this.lowerBound = lowerBound;
		this.upperBound = upperBound;
		origLowerBound = lowerBound;
		origUpperBound = upperBound;
	}
	
	public int getLowerBound() {
		return lowerBound;
	}
	
	public int getUpperBound() {
		return upperBound;
	}
	

	public int getCurrentGuess() {
		return (int) Math.floor((upperBound + lowerBound)/2);
	}
	
	public void higher() {
		if(upperBound-lowerBound == 1) {
			lowerBound = upperBound;
		}
		else {
			lowerBound = getCurrentGuess();
		}
	}

	public void lower() {
		upperBound = getCurrentGuess();
	}

	public void reset() {
		lowerBound = origLowerBound;
		upperBound = origUpperBound;
	}
	
}
