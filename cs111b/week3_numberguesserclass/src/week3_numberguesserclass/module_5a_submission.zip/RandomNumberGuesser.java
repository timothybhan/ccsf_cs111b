package week3_numberguesserclass;
import java.util.Random;

public class RandomNumberGuesser extends NumberGuesser {
	private int randNum;
	
	public RandomNumberGuesser() {
		lowerBound = 1;
		upperBound = 100;
		origLowerBound = lowerBound;
		origUpperBound = upperBound;
		randNum = generateRandomNumber();
	}
	
	public RandomNumberGuesser(int lowerBound, int upperBound) {
		this.lowerBound = lowerBound;
		this.upperBound = upperBound;
		origLowerBound = lowerBound;
		origUpperBound = upperBound;
		randNum = generateRandomNumber();
	}
	
	public int generateRandomNumber() {
		Random randGen = new Random();
		return randGen.nextInt(upperBound-lowerBound+1) + lowerBound;
	}
	
	@Override
	public int getCurrentGuess() {
		return randNum;
	}


	public void higher() {
		if (getCurrentGuess() == upperBound){
			lowerBound = upperBound;
		}
		else {
			lowerBound = getCurrentGuess()+1;
		}
		randNum = generateRandomNumber();
	}
	
	public void lower() {
		if(getCurrentGuess() == lowerBound) {
			upperBound = lowerBound;
		}
		else {
			upperBound = getCurrentGuess()-1;
		}
		randNum = generateRandomNumber();
	}

}
