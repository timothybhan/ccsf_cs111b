package week3_numberguesserclass;

public class NumberGuesserIllegalStateException extends Exception {
	
	public NumberGuesserIllegalStateException(String errorMessage) {
		super(errorMessage);

	 }

}